package com.mehmetkaragoz.libraryProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
